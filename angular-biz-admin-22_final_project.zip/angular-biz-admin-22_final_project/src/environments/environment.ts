export const environment = {
  production: true,
  api: 'http://localhost:8080/api'
};
