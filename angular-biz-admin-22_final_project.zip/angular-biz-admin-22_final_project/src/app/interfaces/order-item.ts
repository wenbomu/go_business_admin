export interface OrderItem {
  id: string;
  product_title: string;
  price: number;
  quantity: number;
}
