package models

type Permission struct {
	Id   uint   `json:"id"`
	Name string `json:"name"`
}
